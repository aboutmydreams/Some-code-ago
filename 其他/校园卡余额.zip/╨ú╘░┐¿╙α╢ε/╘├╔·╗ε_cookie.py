import requests,json
from bs4 import BeautifulSoup
import time
from flask import Flask,jsonify,session,redirect,url_for,render_template,request,make_response
'''
目标：爬到所有数据且不封号，建立数据库，可以随时查询：输入学号或名字（人性化）
解决思路：1、伪装成一个普通用户，几秒查询一次，随后间隔时间发生细微变化，将
2、代理
3、用好多个账号
方案顺序：先写好一条可以爬到简化数据的，
（再写能够input的，学习框架）
'''
url = 'http://life.ccb.com/tran/WCCMainPlatV5?CCB_IBSVersion=V5&SERVLET_NAME=WCCMainPlatV5&isAjaxRequest=true&TXCODE=NYS101&CHOOSETYPE=1&REGION_CODE=360000&BILL_ITEM=05013'
s = requests.get(url)
cookie = requests.utils.dict_from_cookiejar(s.cookies)

print(cookie,s.cookies)